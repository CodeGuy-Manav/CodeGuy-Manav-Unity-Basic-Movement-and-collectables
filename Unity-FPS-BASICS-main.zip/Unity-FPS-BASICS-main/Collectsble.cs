using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Collectsble : MonoBehaviour
{
    public int Health;
    public AudioSource sound;
    void OnTriggerEnter()
    {
        sound.Play();
        
        Health += 1;
        Debug.Log(Health);
        Destroy(transform.GetChild(0).gameObject);
        transform.localScale = new Vector3(0,0,0);
    }
    void update()
    {
        transform.Rotate(0f,0.5f,0f);
    }
}
