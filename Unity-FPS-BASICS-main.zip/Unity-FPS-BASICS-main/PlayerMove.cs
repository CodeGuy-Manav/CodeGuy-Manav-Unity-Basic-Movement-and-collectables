using UnityEngine;

public class PlayerMove : MonoBehaviour
{
    public float speed = 0.1f;
    public AudioSource source;
    public AudioClip clip;
    void Update()
    {
        float y = Input.GetAxis("Vertical")*-1*Time.deltaTime;
        Vector3 pos = transform.forward*y*speed;
        transform.position+=pos;
    }
}
