using UnityEngine;

public class PlayerLook : MonoBehaviour
{
    public float CursorSpeed = 80f;   
    public Transform player; 
    void Update()
    {
        Cursor.visible = false;
        Cursor.lockState=CursorLockMode.Locked;
        float x = Input.GetAxis("Mouse X")*CursorSpeed*Time.deltaTime;
        float y = Input.GetAxis("Mouse Y")*CursorSpeed*Time.deltaTime;
        Vector3 angle = Vector3.up*x;
        player.Rotate(angle);
        Vector3 yaxis = -y*Vector3.right;
        transform.Rotate(yaxis);
    }
}
